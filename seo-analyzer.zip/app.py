from flask import Flask, render_template, request
import requests
from bs4 import BeautifulSoup

app = Flask(__name__)

def analizar_seo(url, palabra_clave):
    resultados = {}
    try:
        response = requests.get(url)
        soup = BeautifulSoup(response.text, 'html.parser')

        title = soup.title.string if soup.title else ''
        resultados["Título contiene keyword"] = palabra_clave.lower() in title.lower()

        meta_desc = soup.find("meta", attrs={"name": "description"})
        descripcion = meta_desc["content"] if meta_desc else ''
        resultados["Descripción contiene keyword"] = palabra_clave.lower() in descripcion.lower()

        headers = ' '.join([h.get_text() for h in soup.find_all(['h1', 'h2', 'h3'])])
        resultados["Encabezados contienen keyword"] = palabra_clave.lower() in headers.lower()

        texto = soup.get_text()
        resultados["Cuerpo contiene keyword"] = palabra_clave.lower() in texto.lower()
        resultados["Frecuencia de keyword"] = texto.lower().count(palabra_clave.lower())
        resultados["Longitud del contenido"] = len(texto.split())

        imagenes_sin_alt = [img for img in soup.find_all("img") if not img.get("alt")]
        resultados["Imágenes sin 'alt'"] = len(imagenes_sin_alt)

        return resultados
    except Exception as e:
        return {"Error": str(e)}

@app.route('/', methods=['GET', 'POST'])
def index():
    resultados = None
    if request.method == 'POST':
        url = request.form['url']
        keyword = request.form['keyword']
        resultados = analizar_seo(url, keyword)
    return render_template('index.html', resultados=resultados)

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000)
